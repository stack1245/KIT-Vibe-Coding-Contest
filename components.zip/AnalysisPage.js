import AnalysisUploadPanel from './AnalysisUploadPanel';
import AppHeader from './AppHeader';
import DashboardStyles from './DashboardStyles';
import PageVideoBackdrop from './PageVideoBackdrop';
import styles from './AnalysisPage.module.css';

export default function AnalysisPage() {
  return (
    <div className="dashboard-page">
      <DashboardStyles />
      <AppHeader />
      <PageVideoBackdrop className="dashboard-video-backdrop" />
      <main className="dashboard-shell">
        <section className="dashboard-card">
          <p className="dashboard-eyebrow">Analysis</p>
          <h1>파일 분석 워크스페이스</h1>
          <p className="dashboard-subtext">정적 분석 기능을 붙이기 전 단계지만, 실제 제품 화면처럼 분석 흐름과 준비 상태를 한눈에 볼 수 있도록 정리했습니다.</p>
          <div className="dashboard-actions">
            <a className="dashboard-button secondary" href="/dashboard">프로필 보기</a>
          </div>

          <div className={styles.analysisHeroGrid}>
            <AnalysisUploadPanel />

            <article className="dashboard-panel">
              <h2>분석 파이프라인</h2>
              <ul className={styles.analysisStepList}>
                <li><span>1</span><div><strong>입력 수집</strong><p>파일 업로드 후 텍스트/실행파일 여부와 기본 메타데이터를 확인합니다.</p></div></li>
                <li><span>2</span><div><strong>업로드 선별</strong><p>Codex 우선 분류와 기본 안전 규칙으로 분석 가치가 있는 파일만 저장합니다.</p></div></li>
                <li><span>3</span><div><strong>분석 큐 준비</strong><p>승인된 파일을 루트 upload 디렉토리 아래 사용자 폴더에 정리합니다.</p></div></li>
                <li><span>4</span><div><strong>취약점 분석</strong><p>다음 단계에서 정적 분석과 패치 가이드 생성을 연결할 예정입니다.</p></div></li>
              </ul>
            </article>
          </div>

          <div className="dashboard-grid">
            <article className="dashboard-panel">
              <h2>지원 예정 입력 형식</h2>
              <div className={styles.analysisChipGroup}>
                <span className={styles.analysisChip}>Single File Upload</span>
                <span className={styles.analysisChip}>Batch Source Upload</span>
                <span className={styles.analysisChip}>Codex Screening</span>
                <span className={styles.analysisChip}>Upload Capacity Guard</span>
              </div>
              <p className="dashboard-panel-text">현재는 로컬 파일 업로드를 우선 지원하고, 이후 GitHub 저장소 연결과 프로젝트 단위 스캔으로 확장할 수 있게 구조를 열어둡니다.</p>
            </article>

            <article className="dashboard-panel">
              <h2>우선 적용 예정 진단 항목</h2>
              <ul className="dashboard-list">
                <li><span>입력 검증</span><strong>Injection 계열</strong></li>
                <li><span>인증/인가</span><strong>권한 우회 및 세션 처리</strong></li>
                <li><span>저장 데이터</span><strong>민감 정보 노출</strong></li>
                <li><span>구성 오류</span><strong>위험한 기본 설정</strong></li>
              </ul>
            </article>

            <article className="dashboard-panel">
              <h2>결과 화면 계획</h2>
              <p className="dashboard-panel-text">분석 결과는 취약점 목록, 심각도 필터, 코드 위치, 공격 시나리오, 수정 가이드, 히스토리 비교까지 이어지도록 구성할 예정입니다.</p>
              <div className="dashboard-actions">
                <a className="dashboard-button secondary" href="/dashboard">프로필로 돌아가기</a>
              </div>
            </article>

            <article className="dashboard-panel">
              <h2>현재 상태</h2>
              <p className="dashboard-panel-text">인증 보호, 업로드 API, 저장 경로, 총용량 10TB 제한, 기본/Codex 선별 흐름까지 연결했습니다. 다음 구현 단계는 실제 취약점 분석 엔진과 결과 카드 생성입니다.</p>
            </article>
          </div>
        </section>
      </main>
    </div>
  );
}
