'use client';

import { useMemo, useState } from 'react';
import styles from './AnalysisPage.module.css';

function formatBytes(value) {
  if (!Number.isFinite(value)) {
    return '-';
  }

  const units = ['B', 'KB', 'MB', 'GB', 'TB'];
  let amount = value;
  let unitIndex = 0;

  while (amount >= 1024 && unitIndex < units.length - 1) {
    amount /= 1024;
    unitIndex += 1;
  }

  return `${amount.toFixed(amount >= 10 || unitIndex === 0 ? 0 : 1)} ${units[unitIndex]}`;
}

export default function AnalysisUploadPanel() {
  const [selectedFiles, setSelectedFiles] = useState([]);
  const [submitting, setSubmitting] = useState(false);
  const [feedback, setFeedback] = useState({ message: '', type: 'neutral' });
  const [result, setResult] = useState(null);

  const totalSelectedSize = useMemo(() => {
    return selectedFiles.reduce((total, file) => total + file.size, 0);
  }, [selectedFiles]);

  function handleChange(event) {
    const nextFiles = Array.from(event.target.files || []);
    setSelectedFiles(nextFiles);
    setResult(null);

    if (!nextFiles.length) {
      setFeedback({ message: '', type: 'neutral' });
      return;
    }

    setFeedback({
      message: `${nextFiles.length}개 파일을 선택했습니다.`,
      type: 'neutral',
    });
  }

  async function handleSubmit(event) {
    event.preventDefault();

    if (!selectedFiles.length) {
      setFeedback({ message: '업로드할 파일을 먼저 선택해주세요.', type: 'error' });
      return;
    }

    setSubmitting(true);
    setResult(null);
    const formElement = event.currentTarget;

    const formData = new FormData();
    selectedFiles.forEach((file) => {
      formData.append('files', file);
    });

    try {
      const response = await fetch('/api/analysis/upload', {
        method: 'POST',
        credentials: 'same-origin',
        body: formData,
      });
      const payload = await response.json().catch(() => ({}));

      setResult(payload);

      if (!response.ok) {
        throw new Error(payload.message || '업로드를 처리하지 못했습니다.');
      }

      setFeedback({ message: payload.message || '업로드가 완료되었습니다.', type: 'success' });
      setSelectedFiles([]);
      formElement.reset();
    } catch (error) {
      setFeedback({ message: error.message || '업로드에 실패했습니다.', type: 'error' });
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <article className="dashboard-panel">
      <p className={styles.analysisBadge}>업로드 활성화</p>
      <h2>분석 대상 업로드</h2>
      <p className="dashboard-panel-text">
        업로드 전에 텍스트 기반 소스 코드인지, 웹/앱 분석 가치가 있는지, 의심 파일인지 1차 분류합니다.
        분석 대상으로 인정된 파일만 루트 <code>upload/</code> 아래 사용자 폴더에 저장합니다.
      </p>

      <form className={styles.uploadForm} onSubmit={handleSubmit}>
        <label className={styles.analysisDropzoneBox} htmlFor="analysis-upload-input">
          <strong>Upload Zone</strong>
          <span>소스 코드, 설정 파일, 프로젝트 파일, zip/tar 압축파일을 선택하세요.</span>
          <span>실행 파일/바이너리/의심 스크립트는 자동 차단됩니다.</span>
        </label>

        <input
          id="analysis-upload-input"
          className={styles.hiddenInput}
          type="file"
          multiple
          onChange={handleChange}
        />

        <div className={styles.uploadMetaRow}>
          <span>선택 파일 {selectedFiles.length}개</span>
          <span>총 {formatBytes(totalSelectedSize)}</span>
        </div>

        {selectedFiles.length ? (
          <ul className={styles.selectedFileList}>
            {selectedFiles.map((file) => (
              <li key={`${file.name}-${file.size}`}>
                <strong>{file.name}</strong>
                <span>{formatBytes(file.size)}</span>
              </li>
            ))}
          </ul>
        ) : null}

        <div className="dashboard-actions">
          <button className="dashboard-button" type="submit" disabled={submitting}>
            {submitting ? '검사 중...' : '업로드하고 검사하기'}
          </button>
        </div>
      </form>

      {feedback.message ? (
        <p className={feedback.type === 'error' ? styles.uploadError : feedback.type === 'success' ? styles.uploadSuccess : styles.uploadNeutral}>
          {feedback.message}
        </p>
      ) : null}

      {result ? (
        <div className={styles.uploadResultGrid}>
          <article className={styles.uploadResultCard}>
            <h3>허용된 파일</h3>
            <p>{result.accepted?.length || 0}개</p>
            <ul className={styles.uploadResultList}>
              {(result.accepted || []).map((entry) => (
                <li key={entry.storedPath}>
                  <strong>{entry.originalName}</strong>
                  <span>{entry.storedPath}</span>
                  <span>{entry.reason}</span>
                </li>
              ))}
            </ul>
          </article>

          <article className={styles.uploadResultCard}>
            <h3>제외된 파일</h3>
            <p>{result.rejected?.length || 0}개</p>
            <ul className={styles.uploadResultList}>
              {(result.rejected || []).map((entry, index) => (
                <li key={`${entry.originalName}-${index}`}>
                  <strong>{entry.originalName}</strong>
                  <span>{entry.reason}</span>
                </li>
              ))}
            </ul>
          </article>
        </div>
      ) : null}
    </article>
  );
}
